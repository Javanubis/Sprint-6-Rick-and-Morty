<template>
  <Products />
</template>

<script>
import Products from '@/components/Products.vue'

export default {
    components:{
        Products,
    }


}

</script>
<style>

</style>