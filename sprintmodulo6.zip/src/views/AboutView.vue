<template>
<div class="container">
  <div class="about">
    <h1>Acerca de Nosotros</h1>
    <p>Sprint final módulo 6 Terminado</p>

  </div>
  </div>
</template>
<script>

</script>
<style >

</style>

